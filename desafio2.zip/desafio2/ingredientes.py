#tipo de ingredientes 
vegetales = ["tomate", "aceitunas", "champiñones"]
proteicos = ["pollo", "vacuno", "carne vegetal"]
masas = ["tradicional", "delgada"]